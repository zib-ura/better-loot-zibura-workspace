"""Resolve source mod ownership independently of resource namespace."""
import json
from pathlib import Path


class ModPackResolver:
    def __init__(self, manifest, target, structure_dir):
        self.structure_dir = Path(structure_dir)
        records = json.loads(Path(manifest).read_text(encoding="utf-8"))
        self.folders = {}
        self.namespaces = {}
        self.known = {}
        for group in records.values():
            for mod in group.get("mods", []):
                ids = mod.get("mod_ids", [])
                if len(ids) == 1:
                    self.known.setdefault(self._identity(mod["mod_folder"]), set()).add(ids[0])
        for mod in records.get(target, {}).get("mods", []):
            folder = mod["mod_folder"]
            ids = mod.get("mod_ids", [])
            if not ids:
                ids = list(self.known.get(self._identity(folder), []))
            if len(ids) == 1:
                self.folders[folder] = ids[0]
        # Namespaces are discovered from actual source directories, not guessed
        # from the mod ID. This supports multiple namespaces per mod.
        for mod_dir in (self.structure_dir.iterdir() if self.structure_dir.is_dir() else []):
            if not mod_dir.is_dir():
                continue
            modid = self.folders.get(mod_dir.name)
            if not modid:
                continue
            data = mod_dir / "data"
            if data.is_dir():
                for ns in data.iterdir():
                    if ns.is_dir():
                        self.namespaces.setdefault(ns.name, set()).add(modid)

    @staticmethod
    def _identity(folder):
        import re
        # Normalize common mod filename version/loader differences for cross-version fallback.
        value = folder.lower()
        value = re.sub(r"\[[^]]*]", "", value)
        value = re.sub(r"(?:forge|neoforge|fabric|mc|universal|port|unofficial)", "", value)
        value = re.sub(r"\d+(?:[.\-+]\d+)*[a-z]?", "", value)
        return re.sub(r"[^a-z]", "", value)

    def for_source(self, data_dir, namespace):
        path = Path(data_dir)
        try:
            folder = path.relative_to(self.structure_dir).parts[0]
        except (ValueError, IndexError):
            return self.for_namespace(namespace)
        return self.folders.get(folder) or self.for_namespace(namespace)

    def for_namespace(self, namespace):
        candidates = self.namespaces.get(namespace, set())
        if len(candidates) == 1:
            return next(iter(candidates))
        if len(candidates) > 1:
            raise ValueError(f"Ambiguous namespace {namespace!r} belongs to {sorted(candidates)}")
        return namespace

    def data_root(self, packs_dir, modid):
        if not modid or modid in {".", ".."} or "/" in modid or "\\" in modid:
            raise ValueError(f"Invalid modid: {modid!r}")
        return Path(packs_dir) / modid / "data"
